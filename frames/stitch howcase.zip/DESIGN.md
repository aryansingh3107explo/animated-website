---
name: Luminous Pure
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#484833'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#797861'
  outline-variant: '#c9c8ad'
  surface-tint: '#5f6200'
  primary: '#5f6200'
  on-primary: '#ffffff'
  primary-container: '#d9e021'
  on-primary-container: '#5e6100'
  inverse-primary: '#c8cf00'
  secondary: '#6b5a5d'
  on-secondary: '#ffffff'
  secondary-container: '#f5dde1'
  on-secondary-container: '#726063'
  tertiary: '#5d5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#d7d7d7'
  on-tertiary-container: '#5c5d5e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4eb2f'
  primary-fixed-dim: '#c8cf00'
  on-primary-fixed: '#1c1d00'
  on-primary-fixed-variant: '#474a00'
  secondary-fixed: '#f5dde1'
  secondary-fixed-dim: '#d8c1c5'
  on-secondary-fixed: '#25181b'
  on-secondary-fixed-variant: '#534346'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.5'
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.15em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  section-gap: 120px
---

## Brand & Style

The design system is engineered for a high-end, luxury skincare audience that values clinical precision fused with organic vitality. The brand personality is "Vibrant Serenity"—combining the high-energy pop of botanical lime with the calming, editorial sophistication of a premium boutique.

The visual style merges **Apple-inspired Minimalism** with **Advanced Glassmorphism**. We utilize expansive whitespace, high-transparency surfaces, and ultra-refined typography to create an "airy" atmosphere. Every element should feel light enough to float, mirroring the lightweight, hydrating nature of the products. The emotional response is one of clarity, refreshment, and modern luxury.

## Colors

This color palette is a juxtaposition of organic energy and soft elegance.
- **Lime Vitality (Primary):** Extracted from the core product, used sparingly for calls to action, active states, and critical highlights to draw the eye with high-energy contrast.
- **Blush Petal (Background):** A soft, matte pink that serves as the canvas. It should be applied with subtle radial gradients (e.g., center #FFFFFF to edges #F9E1E5) to create a sense of depth and glow.
- **Optical White (Surface):** Used for glassmorphic containers. These surfaces should maintain 60-80% opacity with a 24px-32px backdrop blur.
- **Obsidian (Text):** A deep, near-black charcoal to ensure high-end readability and editorial weight without the harshness of pure black.

## Typography

The typography system relies on a "High-Low" contrast model. 

**Headlines** utilize **Playfair Display** to inject a sense of heritage and luxury. Large display sizes should use tight letter-spacing to feel cohesive and impactful. 

**Body Text** and functional UI elements use **Inter**, chosen for its clinical clarity and neutral stance. To maintain the "airy" feel, body copy should utilize generous line-height (1.6) and a slight positive letter-spacing (0.01em) to ensure the layout feels breathable and premium. **Label-caps** are used for category tags and small eyebrows to provide a structured, organized feel.

## Layout & Spacing

The layout philosophy follows a **Fixed-Fluid Hybrid**. Content is contained within a 1280px max-width grid to maintain editorial control on ultra-wide screens, while internal margins and gutters use a strict 8px base-unit.

- **Whitespace as a Component:** Treat empty space as a luxury feature. Use large `section-gap` tokens (120px+) to separate distinct product stories.
- **Mobile Reflow:** On mobile, margins reduce to 20px, and section gaps compress to 60px.
- **Alignment:** Use a 12-column grid for desktop. Imagery should often bleed off-canvas or span 8-10 columns to break the "boxy" feel and create a more dynamic, liquid flow.

## Elevation & Depth

Depth in this design system is achieved through **Luminous Stacking** rather than traditional shadows.

1.  **Base Layer:** The soft pink background with a subtle "inner glow" gradient.
2.  **Middle Layer (Glass):** UI containers use a 70% white fill with a 32px backdrop blur. Borders are 1px solid white at 20% opacity to create a "catch-light" on the edge.
3.  **Top Layer (Active):** Interactive elements or primary buttons use a soft, ultra-diffused shadow (0px 20px 40px rgba(0,0,0,0.04)) to lift them slightly off the glass.

Avoid heavy, dark shadows. The goal is to make components feel like they are carved out of frosted glass or resting on a pool of light.

## Shapes

The shape language is defined by **Continuous Curvature**. 

While the base `roundedness` is set to 2 (0.5rem), the "2xl" aesthetic requested for this system translates to the heavy use of `rounded-xl` (1.5rem) and `rounded-2xl` (2rem) for cards and main containers. 

Buttons should utilize a **Pill-shape** (fully rounded) to contrast against the structured grid and mimic the ergonomic curves of premium skincare packaging.

## Components

- **Buttons:** Primary buttons are pill-shaped, filled with the Lime-green (#D9E021). Text is Obsidian. On hover, the button should subtly glow using a lime-tinted shadow.
- **Glass Cards:** Used for product listings. Features a 1px soft white border and a 32px backdrop blur. Content inside should have generous 32px padding.
- **Input Fields:** Minimalist design. Only a bottom border (1px Obsidian at 20% opacity) that transitions to full Lime-green on focus. Use Inter 14px for placeholder text.
- **Chips/Tags:** Small, pill-shaped containers with a semi-transparent white background and 12px uppercase Inter text.
- **Image Treatment:** Product photography should have "floating" shadows—soft, desaturated, and cast downwards to emphasize the 3D nature of the glassmorphic environment.
- **Progress Indicators:** Use thin 2px lines in Lime-green to indicate scroll progress or carousel states, maintaining a technical, precise look.